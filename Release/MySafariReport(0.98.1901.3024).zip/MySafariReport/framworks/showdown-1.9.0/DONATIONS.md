We would like to thank everyone that contributed to this library. If you find our library useful and wish to donate as well, you can do so [through patreon](https://www.patreon.com/showdownjs) or directly [through paypal](https://www.paypal.me/tiviesantos)!! Your contribution will be greatly appreciated.

# Sponsors

## Platinum Supporters

## Gold Supporters

## Silver Supporters


# Patron Supporters

## Awesome Supporter

## Cool Supporter

## Supporter

 - Ricardo Jordão
 
 - Tiago Silva


---

# One Time Donors

- [**Learn on demand Systems**](http://www.learnondemandsystems.com/) (1000$)

- **Nothing AG** (25€)

    > Thank you for developing Showdown :)

- **Sam Huffman** (15$)

    > Thanks for the great work on showdown.js! I've been looking for a good solution to serve wiki-like text to a browser and render as
    HTML but nearly gave up after mixed success with wikitext. Your library gets me very close to where I want to be.

- **Maya Lekova** (10$)

    > Great work with the showdown library! I just used it and it worked exactly the way I expected 
      (given a complex inline HTML inside the Markdown, which renders fine with other viewers). 
      The other libraries I've tried (markdown-it and marked) produced a lot of bogus output. Y
      our library saved me at least half a day, thanks! Good luck :)

- **Lin Wang** (10$)

- **Walter Schnell** (10$)

- **ivanhjc** (5$)

- **Asbjørn Ulsberg** (5$)

    > Thanks for the ShowdownJS support!

- **Juan Marcelo Russo** (1$)
