$(document).ready(function(){
    setPrivacyPolicy("#privacy-policy-content")
    M.AutoInit();
})
