$.ajax({
    url : "/modules/footer/footer.html",
    dataType: "text",
    success : function (data) {
        $("body").append(data)
        setPrivacyPolicy("#privacy_policy_modal_content")
    }
});


$(document).ready(function(){
    setPrivacyPolicy("#privacy-policy-content")
    M.AutoInit();
})
